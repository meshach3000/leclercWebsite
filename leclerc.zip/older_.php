<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>LeClerc TT</title>
</head>

<body>
<div align="center">
 <img src="img/logos/LeClercLogo_med_draw_1.png" width="334" height= "306" alt="logo">
</div>
</body>
</html>
